package Server;

import java.util.ArrayList;

import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;

@WebService
@SOAPBinding(style = Style.RPC)
public interface Server_Interface {
	
	public boolean login(String id);
	
	public Boolean[] createRoom(String id, String room_Number, String date, String[] List_Of_Time_Slots);
	
	public Boolean[] deleteRoom(String id, String room_Number, String date, String[] List_Of_Time_Slots);
	
	public String bookRoom(String id, String campusName, String roomNumber, String date, String timeslot);
	
	public String getAvailableTimeSlot(String id, String date);
	
	public Boolean cancelBooking(String id, String bookingID);
	
	public String changeReservation(String id, String bookingID, String new_campus_name, String new_room_no, String new_time_slot);
	
}
