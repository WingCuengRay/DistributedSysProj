package Server;

import javax.xml.ws.Endpoint;



public class Server_Publish {

	public static void main(String[] args) throws Exception {
		
		Endpoint endpoint = Endpoint.publish("http://localhost:" + args[1] + "/Replica_Ivy_Server", new ServerImpl(args[0], Integer.valueOf(args[2])));
		System.out.println(endpoint.isPublished());

	}

}
