package Server;

public enum RequestType {
	login,
	creatRoom, deleteRoom,
	bookRoom, cancelBooking, getAvailableTimeSlot,
	changeReservation
};
