package Server;

import Logger.LogItem;
import Logger.LogWriter;
import RoomRecords.RoomRecords;
import RoomRecords.Tools;
import Server.Campus;
import Server.UDPrequest;
import UserSystem.UserSystem;

import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;

@WebService(endpointInterface = "Server.Server_Interface")
@SOAPBinding(style = Style.RPC)
public class ServerImpl implements Server_Interface {
	
	private String campusName;
	private Campus campus;
	private UserSystem users;
	private RoomRecords roomRecords;
	private LogWriter writer;
	private Tools tools;
	private ReadWriteLock lock;
	
	public ServerImpl(String campusName, int insideUDPListenPort) throws Exception {
		this.campusName = campusName;
		campus = new Campus();
		users = new UserSystem(campusName);
		roomRecords = new RoomRecords(campusName);
		lock = new ReentrantReadWriteLock();
		writer = new LogWriter(campusName+".log");
		tools = new Tools();
		
		//int UDPlistenPort = campus.getUDPlistenPort(campusName);
		DatagramSocket SeverSocket = new DatagramSocket(insideUDPListenPort);
		
		String threadName = campusName + "InsideListen";
		ListenThread listen = new ListenThread(threadName, SeverSocket, roomRecords);
		listen.start();
		
	}
	
	@Override
	public boolean login(String id) {
		
		String[] args = new String[]{id};
		LogItem log = new LogItem(RequestType.login, args);
		
		boolean result = users.Login(id);
		
		log.setResult(result);
		writer.write(log);
		
		return result;
		
       
	}
	
	public Boolean[] createRoom(String id, String room_Number, String date, String[] list_Of_Time_Slots) {
		
		Boolean[] resultArray = new Boolean[list_Of_Time_Slots.length];
        
		for(int i = 0; i < list_Of_Time_Slots.length; i++ ) {
        	String[] args = new String[]{id, room_Number, date, list_Of_Time_Slots[i]};
        	LogItem log = new LogItem(RequestType.creatRoom, args);
        		
        	resultArray[i] = roomRecords.creatRoom(id, room_Number, date, list_Of_Time_Slots[i]);
        	
        	log.setResult(resultArray[i]);
    		writer.write(log);
        	}
        	return resultArray;
	}

	 
	public Boolean[] deleteRoom(String id, String room_Number, String date, String[] List_Of_Time_Slots) {
		
		Boolean[] resultArray = new Boolean[List_Of_Time_Slots.length];

        for (int i = 0; i < List_Of_Time_Slots.length; i++ ) {
        	String[] args = new String[]{id, room_Number, date, List_Of_Time_Slots[i]};
            LogItem log = new LogItem(RequestType.deleteRoom, args);

        	//if room haven't been booked, delete it directly;
        	if (roomRecords.getbookingID(room_Number, date, List_Of_Time_Slots[i]).equals("")) {
        		//System.out.println("bookingID is null");
        		resultArray[i] = roomRecords.deleteRoom(id, room_Number, date, List_Of_Time_Slots[i]);
        		
        		log.setResult(resultArray[i]);
        		writer.write(log);
        		
        	}
        		
        	//if room is booked, delete it and minus bookCount at the same time;
        	else {
        		System.out.println("bookingID is not null");
        		String bookingID = roomRecords.getbookingID(room_Number, date, List_Of_Time_Slots[i]);
        		String studentID = bookingID.substring(bookingID.length()-8);
        		String week = tools.toWeekFromBookingID(bookingID, roomRecords);
        		users.minusBookingCount(studentID, week);
        		resultArray[i] = roomRecords.deleteRoom(id, room_Number, date, List_Of_Time_Slots[i]);
        		
        		log.setResult(resultArray[i]);
        		writer.write(log);
        	}
        }
        
        return resultArray;
       
	}

	 
	public String bookRoom(String id, String aimCampus, String roomNumber, String date, String timeslot) {
		
		String[] args = new String[]{id, aimCampus, roomNumber, date, timeslot};
        LogItem log = new LogItem(RequestType.bookRoom, args);
		
        String week = "";
		String bookingID = "";
			
		week = Tools.toWeekFromDate(date);
		// can not more than 3 times a week
		if (users.getBookingCount(id, week) >= 3) {
				
			log.setResult(false);
    		writer.write(log);
			return "";
		}
		
		//according the campusName, invoke different method, get the bookingID
		if (aimCampus.equals(campusName)) {
			//System.out.println("Local server bookRoom");
			bookingID = roomRecords.bookRoom(aimCampus, id, roomNumber, date, timeslot);
			
		}
		else {
			//System.out.println("UDP server bookRoom");
			//int SeverRequstPort = campus.getUDPrequestPort(campusName);
			int UDPlistenPort = campus.getInsideUDPlistenPort(aimCampus);
				
			String command = "bookRoom(" + aimCampus + ", " + roomNumber + ", " + date + ", " + timeslot + ", " + id +")";
			bookingID = UDPrequest.UDPbookRoom(command, UDPlistenPort);
		}
		
		//according to bookingID, write the logFile
		if ( bookingID != null && !bookingID.equals("")) {
			//System.out.println("bookingID is not null or empty" + bookingID);
			bookingID = bookingID.trim();
			users.plusBookingCount(id, week);
			
			log.setResult(true);
			log.setResponse(bookingID);
    		writer.write(log);
		}
		else {
			bookingID = "";
			
			log.setResult(false);
    		writer.write(log);
		}
		
		return bookingID;
      
	}

	public String getAvailableTimeSlot(String id, String date)   {
		
		String[] args = new String[]{id, date};
        LogItem log = new LogItem(RequestType.getAvailableTimeSlot, args);
		
        String avail = "";
		for (String each : campus.getCompusList()) {
			System.out.println("each compus: " + each);
			if (each.equals(campusName)) {
				avail = avail + roomRecords.getAvailableTimeSlot(date, id) + "  ";
			}
			else {
				System.out.println("UDP server Available Time");
				//int SeverRequstPort = campus.getUDPrequestPort(campusName);
				int UDPlistenPort = campus.getInsideUDPlistenPort(each);
				String command = "getAvailableTimeSlot(" +id + ", " + date + ")";
				avail = avail + UDPrequest.UDPgetAvailableTimeSlot(command, UDPlistenPort)  + "  ";
			}
		}
		
		log.setResult(true);
		log.setResponse(avail);
		writer.write(log);
		
		return avail;
	}
	
 
	public Boolean cancelBooking(String id, String bookingID)   {
		String[] args = new String[]{id, bookingID};
        LogItem log = new LogItem(RequestType.cancelBooking, args);
		
        String aimCampus = bookingID.substring(0, 3);
        String OriginalStudentID = bookingID.substring(bookingID.length()-8);
        String week = "";
		Boolean ifSuccess = false;
		
		if (!id.equals(OriginalStudentID)) {
			log.setResult(false);
			writer.write(log);
			
			return false;
		}
			
		if (aimCampus.equals(campusName)) {
			System.out.println("Local server cancelBooking");
			week = tools.toWeekFromBookingID(bookingID, roomRecords);
			ifSuccess = roomRecords.cancelBooking(bookingID);	
		}	
			
		else {
			System.out.println("UDP server cancelBooking");
			//int SeverRequstPort = campus.getUDPrequestPort(campusName);
			int UDPlistenPort = campus.getInsideUDPlistenPort(aimCampus);
			
			String commandWeek = "getWeek(" + bookingID + ")";
			week = UDPrequest.UDPgetWeek(commandWeek, UDPlistenPort);
			
			String command = "cancelBooking(" +id + ", " + bookingID + ")";
			ifSuccess =  UDPrequest.UDPcancelBooking(command, UDPlistenPort);		
		}
		
		if (ifSuccess == true) {
			//System.out.println("Minus the count after cancel");
			users.minusBookingCount(id, week);
			
			log.setResult(true);
			writer.write(log);
		}
		
		else {
			log.setResult(false);
			writer.write(log);
		}
		
		return ifSuccess;
       
	}
	 
	public String changeReservation(String id, String bookingID, String new_campus_name, String new_room_no, String new_time_slot)   {	
		String[] args = new String[]{id, bookingID, new_campus_name, new_room_no, new_time_slot};
        LogItem log = new LogItem(RequestType.changeReservation, args);
        
        
		String cancelling_aimCampus = bookingID.substring(0, 3);
		String OriginalStudentID = bookingID.substring(bookingID.length()-8);
		
		if (!id.equals(OriginalStudentID)) {
			log.setResult(false);
			writer.write(log);
			
			return "";
		}
		
        String date = "";
		String week = "";
		String new_bookingID = "";
			
		//int cancelling_SeverRequstPort = campus.getUDPrequestPort(campusName);
		int cancelling_UDPlistenPort = campus.getInsideUDPlistenPort(cancelling_aimCampus);
		String command = "BookingIDexist(" + bookingID + ")";
		String ifexist = UDPrequest.UDPBookingIDexist(command, cancelling_UDPlistenPort);	
			
		if (ifexist == null || ifexist.equals("")) {
				
			log.setResult(false);
			writer.write(log);
				
			return "";
		}
		else {
			String[] info = ifexist.split(" ");
			date = info[0].trim();
			week = Tools.toWeekFromDate(date);
		}
			
		//int book_SeverRequstPort = campus.getUDPrequestPort(campusName);
		int book_UDPlistenPort = campus.getInsideUDPlistenPort(new_campus_name);
			
		command = "bookRoom(" + new_campus_name + ", " + new_room_no + ", " + date + ", " + new_time_slot + ", " + id +")";
		new_bookingID = UDPrequest.UDPbookRoom(command, book_UDPlistenPort);
			
		if (new_bookingID != null && !new_bookingID.equals("")) {
			new_bookingID = new_bookingID.trim();
			users.plusBookingCount(id, week);
		}
		else {
			log.setResult(false);
			writer.write(log);
				
			return "";
		}
			
		Boolean ifsuccess = cancelBooking(id, bookingID);
			
		if (ifsuccess == false) {
			Boolean cancelNewBooking = cancelBooking(id, new_bookingID);
				
			log.setResult(false);
			writer.write(log);
				
			return "";
		}
		else {
			log.setResult(true);
			log.setResponse(new_bookingID);
			writer.write(log);
		}
		return new_bookingID;
	}


	
	public boolean login(String id, String password) {
		// TODO Auto-generated method stub
		return false;
	}
	
}
