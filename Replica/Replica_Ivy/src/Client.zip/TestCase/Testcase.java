package TestCase;



public class Testcase {
	
	private static String[] timeslot = {"7:30-9:30", "9:30-11:30", "11:30-13:30", "8:30-10:30"};
	private static String[] room = {"201", "202","203"};
	private static String[] date = {"2017-10-01", "2017-10-02","2017-10-03"};

	public static void main(String[] args) throws Exception {
		
		System.out.println("\nPreparing Test");
		ClientAlternative student_KKL = new ClientAlternative("KKLS9999", "123456");
		TestgetConnection(args, student_KKL);
		
		System.out.println("\nLogin as KKL student ");
		TestLogin(student_KKL);
		
		ClientAlternative student_WST = new ClientAlternative("WSTS7777", "123456");
		TestgetConnection(args, student_WST);
		
		System.out.println("\nLogin as WST student ");
		TestLogin(student_WST);
		
		System.out.println("\nTest case 1: Administritor Function");
		ClientAlternative admin_DVL = new ClientAlternative("DVLA1111", "123456");
		TestgetConnection(args, admin_DVL);
		ClientAlternative admin_WST = new ClientAlternative("WSTA1111", "123456");
		TestgetConnection(args, admin_WST);
		
		System.out.println("\nTest case 1-1: Login as DVL administrator ");
		TestLogin(admin_DVL);
		System.out.println("\nLogin as WST administrator ");
		TestLogin(admin_WST);
		System.out.println("Finish the Test of Login");
		
		System.out.println("\nTest case 1-2: Cresat six room ");
		System.out.println("3 rooms in 2017-10-01, 3 rooms in 2017-10-02");
		TestCreatRoom(admin_DVL);
		TestCreatRoom(admin_WST);
		System.out.println("finish the Test of Creat Room");
		
		System.out.println("\nCheck the result after Creating ");
		TestgetAvailableTimeSlot(student_KKL);
		System.out.println("finish the check");
		
		System.out.println("\nTest case 1-3: Delete one room ");
		TestDeleteRoom(admin_DVL);
		TestDeleteRoom(admin_WST);
		System.out.println("finish the Test of Delete Room");
		
		System.out.println("\nCheck the result after deleting ");
		TestgetAvailableTimeSlot(student_KKL);
		System.out.println("finish the check");
		
		System.out.println("\nTest case 2: Student Function");
		System.out.println("\nTest case 2-1: Book room ");
		TestBookRoom(student_KKL);
		System.out.println("\nREbook same room as WST student ");
		TestBookRoom(student_WST);
		System.out.println("finish the Test of Book Room");
		
		System.out.println("\nCheck the result after booking ");
		TestgetAvailableTimeSlot(student_KKL);
		System.out.println("finish the check");
		
		System.out.println("\nTest case 2-2:  Cancel Booking ");
		TestCancelBooking(student_KKL);
		System.out.println("finish the Test of Cancel Booking");
		
		System.out.println("\nCheck the result after Cancel Booking ");
		TestgetAvailableTimeSlot(student_KKL);
		System.out.println("finish the check");
		
		System.out.println("\nTest case 2-3:  Change Reservation ");
		System.out.println("\nChange Reservation as WST student");
		TestChangeReservation(student_WST);
		System.out.println("\nChange Reservation as KKL student");
		TestChangeReservation(student_KKL);
		System.out.println("finish the Test of Change Reservation");
		
		System.out.println("\nCheck the result after Change Reservation ");
		TestgetAvailableTimeSlot(student_KKL);
		System.out.println("finish the check");
		
		System.out.println("finish the Test Case");
		
		System.exit(0);
			
	}

	private static void TestgetConnection(String[] args, ClientAlternative admin) throws Exception {
		admin.getConnection(args);
		System.out.println("Connection builded.....");
	}

	private static void TestLogin(ClientAlternative admin) throws Exception {
		admin.Login();
	}
	
	private static void TestCreatRoom(ClientAlternative admin) throws Exception {
		String command1 = "createRoom(" + room[0] + ", " + date[0] + ", " + timeslot[0] + ", " + timeslot[1] + ", " + timeslot[2] + ")";
		//String command2 = "createRoom(" + room[0] + ", " + date[0] + ", " + timeslot[1] + ")";
		//String command3 = "createRoom(" + room[0] + ", " + date[0] + ", " + timeslot[2] + ")";
		String command4 = "createRoom(" + room[1] + ", " + date[1] + ", " + timeslot[0] + ")";
		String command5 = "createRoom(" + room[1] + ", " + date[1] + ", " + timeslot[1] + ")";
		String command6 = "createRoom(" + room[1] + ", " + date[1] + ", " + timeslot[2] + ")";
		
		System.out.println("\nTry to creat six new room");
		admin.adminFunc(command1);
		//admin.adminFunc(command2);
		//admin.adminFunc(command3);
		admin.adminFunc(command4);
		admin.adminFunc(command5);
		admin.adminFunc(command6);
		System.out.println("Creat Room finish");
		
		System.out.println("\nTry to recreat same room");
		admin.adminFunc(command1);
		
		System.out.println("\nTry to creat room with time confliction");
		String command7 = "createRoom(" + room[0] + ", " + date[0] + ", " + timeslot[3] + ")";
		admin.adminFunc(command7);	
	}
	
	private static void TestDeleteRoom(ClientAlternative admin) throws Exception {
		String command = "deleteRoom(" + room[1] + ", " + date[1] + ", " + timeslot[1] + ", " + timeslot[2] + ")";
		System.out.println(command);
		admin.adminFunc(command);	
		
		System.out.println("\nDelete the Room that doesn't exist");
		admin.adminFunc(command);
	}
	
	private static void TestgetAvailableTimeSlot(ClientAlternative student) throws Exception {
		String command1 = "getAvailableTimeSlot(" + date[0] + ")";
		System.out.println(command1);
		student.studentFunc(command1);
		
		String command2 = "getAvailableTimeSlot(" + date[1] + ")";
		System.out.println(command2);
		student.studentFunc(command2);
	}
	
	private static void TestBookRoom(ClientAlternative student) throws Exception {
		String command1 = "bookRoom(" + "DVL" + ", " + room[0] + ", " + date[0] + ", " + timeslot[0] + ")";
		String command2 = "bookRoom(" + "DVL" + ", " + room[0] + ", " + date[0] + ", " + timeslot[1] + ")";
		String command3 = "bookRoom(" + "DVL" + ", " + room[0] + ", " + date[0] + ", " + timeslot[2] + ")";
		String command4 = "bookRoom(" + "DVL" + ", " + room[1] + ", " + date[1] + ", " + timeslot[0] + ")";
		String command5 = "bookRoom(" + "DVL" + ", " + room[1] + ", " + date[1] + ", " + timeslot[2] + ")";
		
		System.out.println("\nBook three room in a week");
		student.studentFunc(command1);
		student.studentFunc(command2);
		student.studentFunc(command3);
		
		System.out.println("\nBook the forth room in a week");
		student.studentFunc(command4);
		
		System.out.println("\nBook the room that nonexistent");
		student.studentFunc(command5);
	}
	
	private static void TestCancelBooking(ClientAlternative student) throws Exception {
		String command1 = "cancelBooking(" + "DVL68123KKLS9999" + ")";
		student.studentFunc(command1);
		
		System.out.println("\nCancel booking that nonexistent");
		String command2 = "cancelBooking(" + "DVL68123KKLS8888" + ")";
		student.studentFunc(command2);
	}
	
	private static void TestChangeReservation(ClientAlternative student) throws Exception {
		System.out.println("\nChange Room in the same campus DVL");
		String command1 = "changeReservation(DVL29269KKLS9999, DVL" + ", " + room[0] +  ", " + timeslot[2] + ")";
		student.studentFunc(command1);
		
		System.out.println("\nChange Room in the different campus WST");
		String command2 = "changeReservation(DVL51969KKLS9999, WST" + ", " + room[0] +  ", " + timeslot[2] + ")";
		student.studentFunc(command2);
	}
	
	




}
