package TestCase;

import java.net.URL;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;

import Client.ClientConsole;
import Logger.Logger;
import Server.Campus;
import Server.Server_Interface;

public class ClientAlternative {
	
	private Campus campus = new Campus();
	private ClientConsole console = new ClientConsole();
	private String id;
	private String password;
	private String userType;
	private Server_Interface DRRSservice;
	
	
	public ClientAlternative(String id, String password) {
		this.id = id;
		this.password = password;
		userType = id.substring(3, 4);
	}

	public void getConnection(String[] args) throws Exception {
		
		URL url = new URL("http://localhost:" + campus.getWebport(id.substring(0, 3)) + "/Replica_Ivy_Server?wsdl");
		
		QName qName = new QName("http://Server/", "ServerImplService");
		
		Service service = Service.create(url, qName);
		DRRSservice = service.getPort(Server_Interface.class);	
	}
			
	//Login
	public void Login() throws Exception {
		console.login(id, password, DRRSservice);	
	}		
			
	public void adminFunc(String command) throws Exception {
		
		if (!userType.equals("A")) {
			System.out.println("Command error, can not find such command.");
		}
		if (command.equals("quit")) {
			System.exit(0);
		}
		else {
			if (command.startsWith("createRoom") || command.startsWith("deleteRoom")) {
				console.createANDdelete(DRRSservice, command);	
			}
			else {
			System.out.println("Command error, can not find such command.");
			}
		}
	}
	
	public void studentFunc(String command) throws Exception {
		if (!userType.equals("S")) {
			System.out.println("Command error, can not find such command.");
		}
		
		if (command.equals("quit")) {
			System.exit(0);
		}
					
		if (command.startsWith("bookRoom")) {
			String aimCampus = console.getCampusFromBooking(command);
			if (!aimCampus.equals("DVL") && aimCampus.equals("KKL") && aimCampus.equals("WST")) {
				System.out.println("bookRoom start in a nonExist Campus");
				System.exit(0);
			}
			else {
				console.bookRoom(DRRSservice, command);			
			}
		}
					
		if (command.startsWith("cancelBooking")) {
			String aimCampus = console.getCampusFromCancel(command);
						
			if (!aimCampus.equals("DVL") && !aimCampus.equals("KKL") && !aimCampus.equals("WST")) {
				System.out.println("cancelRoom start in a nonExist Campus");
			}
			else{
				console.cancelBooking(DRRSservice, command, id);
			}
		}
					
		if (command.startsWith("getAvailableTimeSlot")) {
			System.out.println("getAvailableTimeSlot begin");
			console.getAvailableTimeSlot(DRRSservice, command);
		}
					
		if (command.startsWith("changeReservation")) {
			System.out.println("changeReservation begin");
			console.changeReservation(DRRSservice, command);
		}
					
		if(!command.startsWith("bookRoom") && !command.startsWith("cancelBooking") 
				&& !command.startsWith("getAvailableTimeSlot") && !command.startsWith("changeReservation")) {
			System.out.println("Command error, can not find such command.");
		}
	}
}

