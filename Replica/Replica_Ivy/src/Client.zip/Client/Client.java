package Client;

import java.net.URL;
import java.util.Scanner;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;

import Logger.Logger;
import Server.Campus;
import Server.Server_Interface;

public class Client {
	
	//static Server_Interface DRRSservice;
	
	public Client() {
		super();
	}

	public static void main(String[] args) throws Exception {
		//Client client = new Client();
		Campus campus = new Campus();
		ClientConsole console = new ClientConsole();

		Scanner input = new Scanner(System.in);
		
		//input the ID;
		System.out.print("Login ID: ");
		String id = input.next();
		if (console.validID (campus, id) == false) {
			System.out.println("Invalid ID");
			//input.close();
			Logger.writeClientLog(id, "Login", false, "Login ID isn't match the pattern");
			System.exit(0);
		}
		
		//input the password
		System.out.print("Login Password: ");
		String password = input.next();
		if (console.validPassword(password) == false) {
			System.out.println("Invalid ID");
			Logger.writeClientLog(id, "Login", false, "Login password isn't match the pattern");
			input.close();
			System.exit(0);
		}
		
		//connect the sever
		//try {
		
		URL url = new URL("http://localhost:" + campus.getWebport(id.substring(0, 3)) + "/DRRS3.3_Server?wsdl");
		
		QName qName = new QName("http://Server/", "ServerImplService");
		
		Service service = Service.create(url, qName);
		Server_Interface DRRSservice = service.getPort(Server_Interface.class);	
       
			
			//Login
			console.login(id, password, DRRSservice);	
			
			String userType = id.substring(3, 4);
			//judge is tDRRSservicee user a "Administrator" or "Student"
			if (userType.equals("A")) {
				
				while (true) {
					System.out.println("Please enter the command: ");
					String command  = input.nextLine();
					command = command.trim();
					
					if (command.equals("quit")) {
						input.close();
						System.exit(0);
					}
					else {
						if (command.startsWith("createRoom") || command.startsWith("deleteRoom")) {
							console.createANDdelete(DRRSservice, command);	
						}
						else {
						System.out.println("Command error, can not find such command.");
						}
					}
				}
			}
			
			if (userType.equals("S")) {
				
				while (true) {
					System.out.println("Please enter the command: ");
					String command  = input.nextLine();
					command = command.trim();
					
					if (command.equals("quit")) {
						input.close();
						System.exit(0);
					}
					
					if (command.startsWith("bookRoom")) {
						String aimCampus = console.getCampusFromBooking(command);
						if (!aimCampus.equals("DVL") && aimCampus.equals("KKL") && aimCampus.equals("WST")) {
							System.out.println("bookRoom start in a nonExist Campus");
							input.close();
							System.exit(0);
						}
						else {
							console.bookRoom(DRRSservice, command);			
						}
					}
					
					if (command.startsWith("cancelBooking")) {
						String aimCampus = console.getCampusFromCancel(command);
						
						if (!aimCampus.equals("DVL") && !aimCampus.equals("KKL") && !aimCampus.equals("WST")) {
							System.out.println("cancelRoom start in a nonExist Campus");
						}
						else{
							console.cancelBooking(DRRSservice, command, id);
						}
					}
					
					if (command.startsWith("getAvailableTimeSlot")) {
						System.out.println("getAvailableTimeSlot begin");
						console.getAvailableTimeSlot(DRRSservice, command);
					}
					
					if (command.startsWith("changeReservation")) {
						System.out.println("changeReservation begin");
						console.changeReservation(DRRSservice, command);
					}
					
					if(!command.startsWith("bookRoom") && !command.startsWith("cancelBooking") 
							&& !command.startsWith("getAvailableTimeSlot") && !command.startsWith("changeReservation")) {
						System.out.println("Command error, can not find such command.");
					}
				}
			}
		/*
		//} // end try
		//catch (Exception e) {
		//	System.out.println("Exception in AdminClient: " + e);
		//}*/
		input.close();
	} 
}
