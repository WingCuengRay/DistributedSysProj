package Client;

import java.util.ArrayList;
import java.util.regex.Pattern;

import Logger.Logger;
import Server.Campus;
import Server.Server_Interface;

public class ClientConsole {
	
	private String userID;
	
	public ClientConsole() {
		userID = "";
	}

	public boolean validID (Campus campus, String id) {
		String idpattern = "[A-Z]{3}[AS]\\d{4}";
		if (!Pattern.matches(idpattern, id)) {
			System.out.println("InValid ID -- Pattern not match");
			return false;
		}
		return campus.containsKey(id.substring(0, 3));
	}
	
	public boolean validPassword(String password) {
		String paspattern = "[a-zA-Z0-9]{6}";
		if (!Pattern.matches(paspattern, password)) {
			System.out.println("InValid Password -- Pattern not match");
			return false;
		}
		return true;
	}
	
	public void login(String id, String password, Server_Interface DRRSservice) throws Exception {
		
		System.out.println("Login " );
		boolean judge = DRRSservice.login(id, password);
		System.out.println(judge);
		if (judge == false ) {
			System.out.println("Wrong ID or Wrong Password!");
			Logger.writeClientLog(id, "Login", false, "Login ID or password isn't correct");
			System.exit(0);
		}
		else {
			userID = id;
			Logger.writeClientLog(id, "Login", true, "Login Success");
			System.out.println("Welcom, " + id);
		}
	}
	

	public void createANDdelete(Server_Interface DRRSservice, String command) throws Exception {
	
		// get each parameter;
		System.out.println("command: " + command);
		String 	parameter = command.substring(command.indexOf("(")+1, command.length()-1);
		//System.out.println("the parameter:  " + parameter);
		String[] para = parameter.split(",");
		
		String room_Number = para[0].trim();
		String date = para[1].trim();
		
		String[] list_Of_Time_Slots = new String[para.length - 2];
		
		for (int i = 2; i < para.length; i++) {
			list_Of_Time_Slots[i-2]= para[i].trim();
		}
		
		System.out.println("List of time slot: ");
		for (String j : list_Of_Time_Slots) {
			System.out.println(j);
		}
		
	//try {
		/* run
		 * createRoom (String room_Number, Date date, String TimeSlot)
		 */
		//ArrayList<Boolean> ifSuccess = new ArrayList<Boolean>();
		if (command.startsWith("createRoom")) {
			Boolean[] ifSuccess1 = DRRSservice.createRoom(userID, room_Number, date, list_Of_Time_Slots);
			
			String result = "";
			for (Boolean j : ifSuccess1) {
				result += j + " ";
			}
			System.out.println("Creat Room Result: " + result);
			Logger.writeClientLog(userID, "Create Room", true, result);
			
		}
		if (command.startsWith("deleteRoom")) {
			Boolean[] ifSuccess2 = DRRSservice.deleteRoom(userID, room_Number, date, list_Of_Time_Slots);
			
			String result = "";
			for (Boolean j : ifSuccess2) {
				result += j + " ";
			}
			System.out.println("Delete Room Result: " + result);
			
			Logger.writeClientLog(userID, "Delete Room", true, result);
			
		}
	//}	catch (Exception ex) {
	//	ifSuccess = 0;
	//	return ifSuccess;
	//}
		
	}
	
	public String getCampusFromBooking(String command) {
		String 	parameter = command.substring(command.indexOf("(")+1, command.length()-1);
		String[] para = parameter.split(",");
		return para[0].trim();
	}
	
	public String getCampusFromCancel(String command) {
		String 	parameter = command.substring(command.indexOf("(")+1, command.length()-1);
		return parameter.substring(0, 3);
	}
	
	public void bookRoom(Server_Interface DRRSservice, String command) throws Exception{
		/* get each parameter;
		 *bookRoom(String campusName, String roomNumber, String date, String timeslot) 
		 */
		String 	parameter = command.substring(command.indexOf("(")+1, command.length()-1);	
		String[] para = parameter.split(",");
		
		String campusName = para[0].trim();
		String room_Number = para[1].trim();
		String date = para[2].trim();
		String list_Of_Time_Slots = para[3].trim();
		
		String bookingID = "";
		//try{
			//System.out.println("connect to Sever");
			bookingID = DRRSservice.bookRoom(userID, campusName, room_Number, date, list_Of_Time_Slots);	
			//System.out.println("booking ID::::::" + bookingID);
			//}	catch (Exception ex) {
			//	return ("");
			//}
		if (bookingID == null || bookingID.equals("")) {
			Logger.writeClientLog(userID, "bookRoom", false, "Command error");
			System.out.println("Command error, please check your command");
		}
		else {
			Logger.writeClientLog(userID, "bookRoom", true, "Success, the bookingID is :" + bookingID);
			System.out.println("Success! the bookingID is :" + bookingID);
		}
	}
	
	
	public void cancelBooking(Server_Interface DRRSservice, String command, String id) throws Exception{
		/* get each parameter;
		 * cancelBooking(String bookingID) 
		 */
		String 	bookingID = command.substring(command.indexOf("(")+1, command.length()-1);
		String  studentID = bookingID.substring(bookingID.length()-8);
		
		Boolean ifSuccess = false;
		if (!studentID.equals(id)) {
			Logger.writeClientLog(userID, "cancelBooking", false, "UserID not matched the booking UserID");
			System.out.println("Failure! studntID in the BookingID is not matched the login ID");
			ifSuccess = false;
		}
		else{
			//System.out.println("connect to local sever to cancelBooking");
			ifSuccess = DRRSservice.cancelBooking(userID, bookingID);	
		}
		
		if (ifSuccess == true)  {
			Logger.writeClientLog(userID, "cancelBooking", true, "Success");
			System.out.println("Successful cancel booking!");
		}
		else{
			Logger.writeClientLog(userID, "cancelBooking", false, "can not find the bookingID");
			System.out.println("Failure, can not find the bookingID");
		}
	}
	
	public void getAvailableTimeSlot(Server_Interface DRRSservice, String command) throws Exception {
		/* get each parameter;
		 * String getAvailableTimeSlot(String date) 
		 */
		String 	date = command.substring(command.indexOf("(")+1, command.length()-1);	

		String avail = null;
		//try{
			avail = DRRSservice.getAvailableTimeSlot(userID, date);	
		//} catch (Exception ex) {
		//	return null;
		//}
		if ( avail == null) {
			Logger.writeClientLog(userID, "getAvailableTimeSlot", false, "Command error");
			System.out.println("Command error, please check your command");
		}
		Logger.writeClientLog(userID, "getAvailableTimeSlot", true, avail);
		System.out.println(avail);
	}

	public void changeReservation(Server_Interface DRRSservice, String command) throws Exception {
		
		String 	parameter = command.substring(command.indexOf("(")+1, command.length()-1);
		//System.out.println("the parameter:  " + parameter);
		String[] para = parameter.split(",");
		
		String bookingID = para[0].trim();
		String studentID = bookingID.substring(bookingID.length()-8);
		//System.out.println("student ID :" + studentID + "  UserID :" + userID);
		String new_campus_name = para[1].trim();
		String new_room_Number = para[2].trim();
		String new_Time_Slots = para[3].trim();
	
		String new_bookingID = "";
		if (!studentID.equals(userID)) {
			Logger.writeClientLog(userID, "changeReservation", false, "UserID not matched the booking UserID");
			System.out.println("Failure! studntID in the BookingID is not matched the login ID");
		}
		else {
			new_bookingID = DRRSservice.changeReservation(userID, bookingID, new_campus_name, new_room_Number, new_Time_Slots);	
		}
		
		if (new_bookingID == null || new_bookingID.equals("")) {
			Logger.writeClientLog(userID, "changeReservation", false, "Command error");
			System.out.println("Command error, please check your command");
		}
		else {
			Logger.writeClientLog(userID, "changeReservation", true, "Success, the new_bookingID is :" + new_bookingID);
			System.out.println("Success! the new_bookingID is :" + new_bookingID);
		}
		
	}

	

	
}
